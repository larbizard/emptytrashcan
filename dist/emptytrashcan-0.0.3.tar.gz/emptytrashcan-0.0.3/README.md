# Empty trash can

A simple function to emtpy your linux trashcan.

# Usage

## As a module

from emptytrashcan import trashcan

can = trashcan.TrashCan
can.empty

## As a script

python emptytrashcan/trashcan.py