# Empty trash can

A simple function to emtpy your linux trashcan.
