# Empty trash can

A simple function to emtpy your linux trashcan.

# Usage

## As a module

from empty_trashcan import trashcan

can = trashcan.TrashCan
can.empty

## As a script

python empty_trashcan/trashcan.py